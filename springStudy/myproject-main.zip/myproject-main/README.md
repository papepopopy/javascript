springboot JPA, board, reply, member, shop
