package com.spring.myproject.constant;

public enum ItemSellStatus {
  SELL, SOLD_OUT
}
